def main():
	import lizs
	import sys
	import os
	colors = {
		"white":'\033[0m',
		"red":'\033[31m' ,
		"green":'\033[32m', 
		"orange":'\033[33m', 
		"blue":'\033[34m' ,
		"purple":'\033[35m' 
	}
	print(colors['orange']+lizs.getlogo()+colors['white'])
	while True:
		command = input(colors['red']+'Root@'+colors['blue']+'Moon# ').split(" ")
		print(""+colors['white'], end='')
		if command[0] == 'python3':
			try:
				os.system('python3 '+command[1])
			except IndexError:
				print(colors['red']+"Args error\nusing: python3 [file]"+colors['white'])
		elif command[0] == 'ls':
			os.system('ls -a > tmp/lslog.log')
			print(colors['red']+lizs.readf('tmp/lslog.log')+colors['white'])
		elif command[0] == 'pent':
			try:
				os.system('cd bin/'+command[1]+' && python3 main.py')
			except IndexError:
				print(colors['red']+"Args error\nusing: pent [modulename]"+colors['white'])
		elif command[0] == 'p':
			try:
				os.system('python3 '+command[1])
			except IndexError:
				print(colors['red']+'Argument\'error'+"\nusing: p [pythonfile]")

main()