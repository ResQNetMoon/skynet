def readf(filename):
	f = open(filename)
	data = f.read()
	f.close()
	return data

def getlogo():
	da = readf('.cmc')
	return da

class prompt:
	def __init__(self):
		self.isAdmin = False
	
	def login(self, uname, password):
		temp_data = readf(".cmcconfig").strip().replace("\n", "").split(";")
		return temp_data
		del temp_data